
//Personal Details Page

7g56<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="pixels2.css">
        <title>

        </title>
        <body>
            <h2 class="h2">Personal Details Page</h2>
            <div class="container" id="div1">
            <label for="fullName" class="lbl" >Full Name </label>    
            <input type="text" class="txtBtn" id="fullname" onclick="nameValidate()"><br><br>
            <label for="email" class="lbl">Email </label>
            <input type="email" class="txtBtn" id="email" onclick="ValidateEmail()"><br><br>
            <label for="number" class="lbl">Mobile No </label>
            <input type="number" class="txtBtn"  id='number' onclick="numberValidate()" ><br><br>
            <button onclick="submit()" class="submit1">Submit</button></div>
           <script>
               function nameValidate()
               { 
                let fname=document.getElementById("fullname");
                //var letters =/^[a-zA-Z\\s]*$/;
                var letters =/^[a-zA-Z]/;
                if(fname.value.match(letters))
                {
                    //return true;
                    console.log(fname.value);
                 }
                else
                 {
                     //alert('Full name must have alphabet characters only ');
                     let reset=document.getElementById('fullname');   
                    reset="";           
                    fname.focus();
                    return false;
                 }
             }
             function ValidateEmail()
             {  
                var uemail=document.getElementById('email');
                var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                if(uemail.value.match(mailformat))
            {
                return true;
                console.log(uemail.value);
            }
            else
            {
                alert("You have entered an invalid email address!");
                uemail.focus();
                return false;
            }
            }

            function numberValidate(){
                var userNumber=document.getElementById('number');
                var numberformat=/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
                if(userNumber.value.match(numberformat)){
                   console.log(userNumber.value);
                }
                else{
                    alert("Enter Valid Number");
                    userNumber.focus();
                    return false;
                }
            }
             function submit(){
                 nameValidate();
                 ValidateEmail();
                 numberValidate();
             }

           </script>
        </body>
    </head>
</html>
if(st>=100 && st<=126)
                    if(st>=127 && st<=152)
                    if(st>=153 && st<=178)
                    if(st>=178 && st<=204)
                    if(st>=205 && st<=230)
                    if(st>=231 && st<=256)
                    if(st>=257 && st<=282)
                    if(st>=283 && st<=308)
                    if(st>=309 && st<=334)
                    if(st>=335 && st<=360)
                    if(st>=361 && st<=386)
                    if(st>=387 && st<=412)
                    if(st>=413 && st<=438)
                    if(st>=439 && st<=464)
                    if(st>=465 && st<=490)
                    if(st>=491 && st<=516)
                    if(st>=517 && st<=542)
                    if(st>=543 && st<=568)
                    if(st>=569 && st<=594)
                    if(st>=595 && st<=620)
                    if(st>=621 && st<=646)
                    if(st>=647 && st<=672)
                    if(st>=673 && st<=698)
                    if(st>=699 && st<=724)
                    if(st>=725 && st<=750)
                    if(st>=751 && st<=776)
                    if(st>=777 && st<=802)
                    if(st>=803 && st<=828)
                    if(st>=829 && st<=854)
                    if(st>=855 && st<=880)
                    if(st>=881 && st<=906)
                    if(st>=907 && st<=932)
                    if(st>=933 && st<=958)
                    if(st>=959 && st<=984)
                    if(st>=985 && st<=1000)563
                    32
                    5555555555555555555555555555555555555[p-;8iiup0;888888u7,]